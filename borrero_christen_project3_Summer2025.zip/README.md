Name: Christen Borrero
Section: #15184
UFL email: christenborrero@ufl.edu
System: 64 bit
Compiler: 14.2.0
SFML version: 2.5.1
IDE: CLion
Other notes: None